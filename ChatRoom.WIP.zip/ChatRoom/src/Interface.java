import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;


public class Interface extends JPanel{


	private static final long serialVersionUID = 1L;
	int x = 100;
	int y = 100;

	public Interface() {
		KeyListener listener = new MyKeyListener();
		addKeyListener(listener);
		setFocusable(true);
	}
	
	private void moveHandler(KeyEvent e){
		String key = KeyEvent.getKeyText(e.getKeyCode());
		if (key.equals("W"))
			moveUp();
		else if (key.equals("S"))
			moveDown();
		else if (key.equals("A"))
			moveLeft();
		else if (key.equals("D"))
			moveRight();
	}
	private void moveUp(){
		for (int i = 0; i < 3; i++)
			y = y - 10;

	}
	private void moveDown(){
		for (int i = 0; i < 3; i++)
			y = y + 10;

	}
	private void moveLeft(){
		for (int i = 0; i < 3; i++)
			x = x - 10;

	}
	private void moveRight(){
		for (int i = 0; i < 3; i++)
			x = x + 10;

	}

	public class MyKeyListener implements KeyListener {
		@Override
		public void keyTyped(KeyEvent e) {
		}

		@Override
		public void keyPressed(KeyEvent e) {
			moveHandler(e);
		}

		@Override
		public void keyReleased(KeyEvent e) {
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.fillRect(x, y, 30, 30);
	}

	public static void main(String[] args) throws InterruptedException {
		JFrame frame = new JFrame("Test");
		Interface game = new Interface();
		frame.add(game);
		frame.setSize(300, 400);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		while (true) {
			game.repaint();
			game.requestFocusInWindow();
			Thread.sleep(10);
		}
	}
}