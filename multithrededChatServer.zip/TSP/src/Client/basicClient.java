package Client;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class basicClient {


	public static void main(String[] args) throws IOException  {
		int socketToUse = 25585;
		String theIP, userName;
		Socket save = null;

		Scanner sc = new Scanner(System.in);

		theIP = connectTo(sc);

		try {
			Socket s = new Socket(theIP,socketToUse);
			save = s;
		} catch (UnknownHostException e) {
			System.out.println("host not found");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("unable to connect");
			e.printStackTrace();
		}


		userName = gotConnect(sc);
		if(save == null){
			System.out.println("there is no connection");
		}
		PrintStream p = new PrintStream(save.getOutputStream());
		Scanner serverIn = new Scanner(save.getInputStream());
		while(true){
			String temp = sc.nextLine();
			System.out.println("gotline");

			p.println(temp);
			System.out.println("sentline");
			while((temp = serverIn.next())!= null){
				
				if(temp == "\n")
					break;
				
				System.out.println(temp);
			}
			System.out.println("broke secondout");
		}

	}



	public static String connectTo( Scanner s){
		System.out.print("Please enter an IP address: "); // ask for an ip addres

		String IP = s.next();// read in address

		System.out.println("Trying " + IP);// tell user what doing
		return IP;// return ip address
	}

	public static String gotConnect(Scanner s){
		System.out.println("You are now connected!");
		System.out.print("Please enter a user neame: ");


		String userName = s.nextLine();
		System.out.println("Welcome " + userName);
		return userName;
	}
}
