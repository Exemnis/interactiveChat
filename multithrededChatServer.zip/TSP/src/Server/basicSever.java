package Server;
 
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class basicSever {

	ArrayList<PrintStream> steams;
	
	public static void main(String[] args) throws IOException {

		basicSever tetst = new basicSever();
		tetst.mainRunner();
	}

	public void mainRunner() throws IOException {

		steams = new ArrayList<PrintStream>();
		ServerSocket s1 = new ServerSocket(25585);
		while(true){
			Socket ss = s1.accept();
			
			System.out.println("made connection");
			
			Scanner sc = null;
			try {
				sc = new Scanner(ss.getInputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			PrintStream p = null;
			try {
				p = new PrintStream(ss.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			steams.add(p);
			Thread listener = new Thread(new portThred(sc, this));
			listener.start();
			
		}
	}

	public void prtintToAll(String temp) {
		// TODO Auto-generated method stub
		for(int i = 0; i < steams.size(); i++)
			steams.get(i).println(temp +" |");
		
	}
}