package Server;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class portThred extends Thread{
	Socket current = null;
	int adder = 0;

	Scanner sc = null;
	basicSever needed;
	public portThred(Scanner s , basicSever j) throws IOException{
		sc = s;
		needed = j;
	}
	public void run() {
		while(true){
			
			String temp  = null;

			if(sc.hasNextLine())
				temp = sc.nextLine();
			System.out.println("got thing");

			
			
			needed.prtintToAll(temp);
			
			System.out.println("printed thing");


		}
	}
}

