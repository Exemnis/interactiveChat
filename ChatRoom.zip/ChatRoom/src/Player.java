import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.*;
import java.awt.Color;


public class Player extends JPanel{
	private double x;
	private double y;
	private Color color;
	private String name;
	private int direction;
	private String roomName;
	
	
	
	public Player (double x, double y, String name, Color color) {
		this.x = x;
		this.y = y;
		this.name = name;
		this.color = color;
	}
	
	
	protected Color getColor () {
		return this.color;
	}
	
	public String getName() {
		return this.name;
	}
	
	
	protected void setLocation(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	//No collisions
	protected void move(double speed) {
		
		switch (this.direction) {
		case 0: return;
		case 1: this.y += speed;return;
		case 2: this.x += speed;return;
		case 3: this.y -= speed;return;
		case 4: this.x -= speed;return;
		default: return;
		}
	}
	
	@Override
	public void paint(Graphics g){
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g.setColor(new java.awt.Color(255, 255, 0));
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.fillRect(10, 10, 30, 30);
	}
	
	
}
