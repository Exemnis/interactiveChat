import java.awt.Graphics;
import java.awt.Color;


public class Player{
	private int x;
	private int y;
	private Color color;
	private String name;




	public Player (int x, int y, String name, Color color) {
		this.x = x;
		this.y = y;
		this.name = name;
		this.color = color;
	}

	protected void moveUp(){
			y = y - 10;

	}
	protected void moveDown(){
			y = y + 10;

	}
	protected void moveLeft(){
			x = x - 10;

	}
	protected void moveRight(){
			x = x + 10;

	}

	public Color getColor () {
		return this.color;
	}

	public String getName() {
		return this.name;
	}

	protected void setName(String name){
		this.name = name;
	}

	protected void setLocation(int x, int y) {
		this.x = x;
		this.y = y;
	}

	
	public void draw(Graphics g, Player player) {
		//image.paintIcon(panel, g, x, y); - commented out because I don't have an ImageIcon
			g.setColor(player.getColor());
			g.fillRect(player.x, player.y, 30, 30);
	}


}
