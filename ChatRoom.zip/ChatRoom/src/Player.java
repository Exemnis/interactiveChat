import java.awt.Graphics;

import java.awt.Color;


public class Player{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int x;
	private int y;
	private Color color;
	private String name;
	private int direction;
	private String roomName;



	public Player (int x, int y, String name, Color color) {
		this.x = x;
		this.y = y;
		this.name = name;
		this.color = color;
	}

	protected void moveUp(){
		//for (int i = 0; i < 3; i++)
			y = y - 10;

	}
	protected void moveDown(){
		//for (int i = 0; i < 3; i++)
			y = y + 10;

	}
	protected void moveLeft(){
		//for (int i = 0; i < 3; i++)
			x = x - 10;

	}
	protected void moveRight(){
		//for (int i = 0; i < 3; i++)
			x = x + 10;

	}

	public Color getColor () {
		return this.color;
	}

	public String getName() {
		return this.name;
	}

	protected void setName(String name){
		this.name = name;
	}

	protected void setLocation(int x, int y) {
		this.x = x;
		this.y = y;
	}

	//No collisions
	protected void move(double speed) {

		switch (this.direction) {
		case 0: return;
		case 1: this.y += speed;return;
		case 2: this.x += speed;return;
		case 3: this.y -= speed;return;
		case 4: this.x -= speed;return;
		default: return;
		}
	}

	protected void setRoomName(String roomName){
		this.roomName = roomName;
	}

	public String getRoomName(){
		return this.roomName;
	}

	public void draw(Graphics g, Player player) {
		//image.paintIcon(panel, g, x, y); - commented out because I don't have an ImageIcon
			g.setColor(player.getColor());
			g.fillRect(player.x, player.y, 30, 30);
	}


}
