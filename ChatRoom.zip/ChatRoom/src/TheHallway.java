import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JPanel;

public class TheHallway extends JPanel {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	Color ted = new Color(0, 0, 255);
	/**
	 * 
	 * Building the Hallway
	 * 
	 **/
	@Override
	public void paint(Graphics m){
		super.paint(m);
		m.setColor(ted);
		Graphics2D g2d = (Graphics2D) m;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.fillRect(0, 100, 600, 600);
	}
}
