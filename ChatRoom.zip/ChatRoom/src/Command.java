import java.io.Serializable;

public class Command implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int OPcode;
	public String data;
	
	public Command (int OPcode, String data){
		this.OPcode = OPcode;
		this.data = data;
	}
	
	
	
}


/*
CLIENT - SERVER
1: player name change
2: room change request
3: chat message



*/

/*
SERVER - CLIENT
1: player name change request
2: room change confirmation
3: server message
4: chat message



*/