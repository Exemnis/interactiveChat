import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;

import javax.swing.*;

import java.awt.Color;
import java.io.ObjectOutputStream;


public class Room extends JPanel{


	private static final long serialVersionUID = 1L;
	ArrayList<Player> players;
	ArrayList<ObjectOutputStream> writers;
	//Background image
	
	public Room() {
		this.players = new ArrayList<Player>();
		writers = new ArrayList<ObjectOutputStream>();
		setFocusable(true);
		//Load Room
		//Load new playerlist
	}
	
	 protected void addPlayer(Player player){
		 players.add(player);
	 }
	 
	 protected void delPlayer(Player player){
		 players.remove(player);
	 }

	 protected void updatePlayer(int index,Player player){
		 players.set(index, player);
	 }
	
	
	public void paintComponent(Graphics g) {
        // Call the original implementation of this method
        super.paintComponent(g);

        // Draw a border
        g.drawRect(0,0,getWidth(),getHeight());
        
        //Draw the hallway
        Graphics2D hall2d = (Graphics2D) g;
		g.setColor(Color.BLUE);
		hall2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		hall2d.fillRect(0, 100, 600, 300);

        // Draw all the players
        for (Player player : players) {
            player.draw(g,player);
        }
        
       
    }

	
	
}