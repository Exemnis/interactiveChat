import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import java.awt.Color;


public class Interface extends JPanel{


	private static final long serialVersionUID = 1L;
	int x = 250;
	int y = 250;
	List<Player> players = new ArrayList<Player>();

	public Interface() {
		setFocusable(true);
	}
	
	 protected void addPlayer(Player player){
		 players.add(player);
	 }

	
	
	
	public void paintComponent(Graphics g) {
        /* Call the original implementation of this method */
        super.paintComponent(g);

        /* Lets draw a black border around the bounds of the component
         * to make it clear where the balls should rebound from */
        g.drawRect(0,0,getWidth(),getHeight());
        Graphics2D hall2d = (Graphics2D) g;
		g.setColor(Color.BLUE);
		hall2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		hall2d.fillRect(0, 100, 600, 300);

        /* Draw all the players we currently have stored in
         * our list. */
        for (Player player : players) {
            player.draw(g,player);
        }
        
       
    }

	
	
}