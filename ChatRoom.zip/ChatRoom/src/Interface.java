import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.*;
import java.awt.Color;


public class Interface extends JPanel{


	private static final long serialVersionUID = 1L;
	int x = 250;
	int y = 250;
	Color ted = new java.awt.Color(0, 0, 255);

	public Interface() {
		setFocusable(true);
	}

	protected void moveUp(){
		//for (int i = 0; i < 3; i++)
			y = y - 10;

	}
	protected void moveDown(){
		//for (int i = 0; i < 3; i++)
			y = y + 10;

	}
	protected void moveLeft(){
		//for (int i = 0; i < 3; i++)
			x = x - 10;

	}
	protected void moveRight(){
		//for (int i = 0; i < 3; i++)
			x = x + 10;

	}

	@Override
	/**
	 * Box Creation method
	 *	Achieved by filling a Rectangle 
	 *
	 */
	public void paint(Graphics g) {
		super.paint(g);

		
		Graphics2D hall2d = (Graphics2D) g;
		g.setColor(ted);
		hall2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		hall2d.fillRect(0, 100, 600, 300);
		
		Graphics2D g2d = (Graphics2D) g;
		g.setColor(new java.awt.Color(255, 0, 0));
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.fillRect(x, y, 30, 30);
	}
	
	


	
	
}