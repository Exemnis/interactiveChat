import java.awt.Color;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 * A multithreaded chat room server.  When a client connects the
 * server requests a screen name by sending the client a request,
 * and keeps requesting a name until a unique one is received. 
 * After a client submits a unique name, the server acknowledges it 
 * by adding them to the hallway. Then all messages from that client
 * will be broadcast to all other clients that have submitted a 
 * unique screen name.
 *
 * Because this is just a teaching example to illustrate a simple
 * chat server, there are a few features that have been left out.
 * Two are very useful and belong in production code:
 *
 *     1. The protocol should be enhanced so that the client can
 *        send clean disconnect messages to the server.
 *
 *     2. The server should do some logging.
 */
public class Server {

	/**
	 * The port that the server listens on.
	 */
	private static final int PORT = 7070;

	/**
	 * The set of all players of clients in the chat room.  Maintained
	 * so that we can check that new clients are not registering name
	 * already in use.
	 */
	private static ArrayList<Room> Rooms = new ArrayList<Room>();

	/**
	 * The application main method, which just listens on a port and
	 * spawns handler threads.
	 */
	public static void main(String[] args) throws Exception {
		System.out.println("The chat server is running.");

		//TODO add rooms less shittily
		Room hallway = new Room();
		Rooms.add(hallway);

		ServerSocket listener = new ServerSocket(PORT);
		try {
			while (true) {
				new Handler(listener.accept()).start();

			}
		} finally {
			listener.close();
		}
	}

	/**
	 * A handler thread class.  Handlers are spawned from the listen
	 * loop and are responsible for a dealing with a single client
	 * and broadcasting its messages.
	 */
	private static class Handler extends Thread {
		private Player player;
		private Socket socket;
		private ObjectInputStream in;
		private ObjectOutputStream out;
		private int room;

		/**
		 * Constructs a handler thread, squirreling away the socket.
		 * All the interesting work is done in the run method.
		 */
		public Handler(Socket socket) {
			this.socket = socket;
		}

		public void newPlayer(Room PlayerRoom) throws IOException, ClassNotFoundException{
			Object input;
			Command command;
			while (true) {
				out.writeObject(new Command(1, ""));
				out.flush();
				input = in.readObject();
				if (input instanceof Command) {
					command = (Command)input;
					if (command.OPcode == 1) {
						boolean isUnique = true;
						for (Room room: Rooms){
							synchronized (room.players) {
								for (Player player: room.players){
									if (player.getName().equals(command.data)){
										isUnique = false;
									}
								}
							}
						}
						if (isUnique) {
							player = new Player(250, 250, command.data, Color.BLACK);
							PlayerRoom.players.add(player);
							break;
						}
					}
				}
			}

		}

		public void roomChangeConfirmation (Room room) throws IOException {
			out.writeObject(new Command(2, ""));
			out.flush();
		}

		public void sendRoomMessage (String message) throws IOException {
			for (ObjectOutputStream writer : Rooms.get(room).writers) {
				writer.writeObject(new Command(3, message));
				out.flush();
			}
		}

		public void sendChatMessage (String message) throws IOException {
			for (ObjectOutputStream writer : Rooms.get(room).writers) {
				writer.writeObject(new Command(4, message));
				out.flush();
			}
		}

		public void updatePlayers(Player player) throws IOException{
			for (int i = 0; i<Rooms.size(); i++){
				for (int j = 0; j < Rooms.get(i).players.size(); j++){
					if (player.getName().equals(Rooms.get(i).players.get(j).getName())){
						Rooms.get(i).updatePlayer(j, player);
					}
				}
			}
			for (ObjectOutputStream writer : Rooms.get(room).writers) {
				writer.writeObject(Rooms.get(room).players);
				out.flush();
			}
		}



		/**
		 * Services this thread's client by repeatedly requesting a
		 * screen name until a unique one has been submitted, then
		 * acknowledges the name and registers the output stream for
		 * the client in a global set, then repeatedly gets inputs and
		 * broadcasts them.
		 */
		public void run() {
			try {

				// Create character streams for the socket.
				out = new ObjectOutputStream(socket.getOutputStream());
				in = new ObjectInputStream(socket.getInputStream());

				room = 0;

				// Request a name from this client.  Keep requesting until
				// a name is submitted that is not already used.  Note that
				// checking for the existence of a name and adding the name
				// must be done while locking the set of players.
				newPlayer(Rooms.get(room));//Very silly TODO TODO TODO SO JANK


				//Send room change to hallway confirmation
				roomChangeConfirmation(Rooms.get(room));

				// Informs all clients that a new client has joined
				Rooms.get(room).writers.add(out);
				sendRoomMessage(player.getName() + " has entered the room");

				// Accept messages from this client and broadcast them.
				// Ignore other clients that cannot be broadcasted to.
				while (true) {
					Object input = null;
					try {
						input = in.readObject();
					} catch (ClassNotFoundException e) {
						System.out.println("ERROR INVALID SERVER MESSAGE DONT HACK KIDS\n");//TODO MAKE POPUP
						e.printStackTrace();
					}

					if (input == null) {
						System.out.println("Horse1");
						return;
					}

					if (input instanceof Command) {
						Command command = (Command) input;
						switch (command.OPcode) {
						case 3:
							sendRoomMessage(player.getName() + ": " + command.data);
							break;
						case 4:
							sendChatMessage(player.getName() + ": " + command.data);
							break;
						}
					}else if(input instanceof Player) {
						player = (Player) input;
						updatePlayers(player);
					}

				}
			} catch (IOException | ClassNotFoundException e) {
				System.out.println(player.getName() + " has left the server");


				try {

					sendRoomMessage(player.getName() + " has left the room");

					//Sockets may or may not close...(probably don't)
					socket.close();
				} catch (IOException a) {
					Rooms.get(room).delPlayer(player);
					Rooms.get(room).writers.remove(out);

				} 
			}
		}
	}
}
